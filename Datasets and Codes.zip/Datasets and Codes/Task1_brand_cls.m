clear;clc

%% load SVI
% X = load('D:\Postdoc\Joint papers\Joint_Tang Xuan\Datasets\SVI-brands.csv');
% X = X/255;

%% load HSI
X = load('D:\Postdoc\Joint papers\Joint_Tang Xuan\Datasets\HSI-brands.csv'); 
X = X/1982;

%% lable
Y = 1:15;Y = repmat(Y,12,1);Y = reshape(Y,180,1);   %% 15-cls

%% split
times = 3;  s = 1;  fold = 10;
m = size(Y,1);  index = 1 + rem(0:m-1,times); 
train = find(index~=s);test = find(index==s);
Xtrain = X(train,:);Ytrain = Y(train,:);
Xtest = X(test,:);Ytest = Y(test,:);
indices = 1 + rem(0:size(Xtrain,1)-1,fold);
% indices = crossvalind('Kfold',ones(size(Xtrain,1),1),fold); 

%% PLS-DA
LV = 10;
for k = 1:fold
    test_ = (indices == k);  train_ = ~test_;
    xtrain = Xtrain(train_,:);    xtest = Xtrain(test_,:);
    ytrain = Ytrain(train_,:);    ytest = Ytrain(test_,:);
    [~,~,ycv] = fast_PLSDA(xtrain,ytrain,xtest,ytest,LV);
    Ycv(test_,:) = ycv;
end
for i = 1:LV
    correct = find(Ytrain - Ycv(:,i) == 0);
    acc = size(correct,1)/size(Ytrain,1);
    results_CV_all(i,:) = acc;
end
[results_CV,para] = max(results_CV_all);
b = find(results_CV_all == results_CV);b = b(1);
[~,~,yp] = fast_PLSDA(Xtrain,Ytrain,Xtest,Ytest,b);yp = yp(:,end);
Yp = yp;

%% K-ELM
% C = 1:10;Gamma = 1:10;
% for i = 1:size(C,2)
%     for j = 1:size(Gamma,2)
%         for k = 1:fold
%             test_ = (indices == k);  train_ = ~test_;
%             xtrain = Xtrain(train_,:);    xtest = Xtrain(test_,:);
%             ytrain = Ytrain(train_,:);    ytest = Ytrain(test_,:);
%             train_data = [ytrain xtrain];
%             test_data = [ytest xtest];
%             [~,~,~,~,ycv] = kernel_elm(train_data,test_data,1,2^C(i),'RBF_kernel',2^Gamma(j));
%             [~,ycv] = max(ycv,[],1);
%             Ycv(test_,:) = ycv';
%         end
%         correct = find(Ytrain - Ycv == 0);
%         acc = size(correct,1)/size(Ytrain,1);
%         accuracy_CV_all(i,j) = acc;
%     end
% end
% [a,b] = find(accuracy_CV_all==max(max(accuracy_CV_all)));
% a = a(end);b = b(end);
% train_data = [Ytrain Xtrain];test_data = [Ytest Xtest];
% [~,~,~,~,yp] = kernel_elm(train_data,test_data,1,2^C(a),'RBF_kernel',2^Gamma(b));
% [~,yp] = max(yp,[],1);yp = yp';
% Yp = yp;
% results_CV = max(max(accuracy_CV_all));

%% results
correct = find(Ytest-Yp == 0);
accuracy_predict = size(correct,1)/size(Ytest,1);
Results = roundn([results_CV accuracy_predict],-4)

%% PCA
figure
% score = tsne(X,'NumDimensions',2);%,'Exaggeration',3,'LearnRate',1000);

[loading,score,~,~,explained,~] = pca(zscore(X));
e1 = roundn(explained(1),-1);
e2 = roundn(explained(2),-1);
e3 = roundn(explained(3),-1);
e4 = roundn(explained(4),-1);

purple_hue = 300; % 紫色在HSV空间的大致色调值
red_hue = 0;      % 红色在HSV空间的色调值

% 设置饱和度和亮度
saturation = 0.5;
value = 0.9; % 降低亮度使得颜色稍微浅一些

% 创建一个15x3的HSV颜色矩阵
num_colors = 15;
hsv_matrix = zeros(num_colors, 3); % 初始化HSV矩阵

% 计算色调值的范围
hue_range = linspace(purple_hue, red_hue, num_colors);

% 填充HSV矩阵
hsv_matrix(:,1) = hue_range / 360; % 将色调值转换为0-1范围
hsv_matrix(:,2) = saturation;
hsv_matrix(:,3) = value;

% 将HSV颜色矩阵转换为RGB颜色矩阵
C = hsv2rgb(hsv_matrix);

plot(-100:1:100,zeros(201,1),':','color','k');hold on
plot(zeros(201,1),-100:1:100,':','color','k');hold on
for i = 1:1:15
    scatter((score(Y==i,1)),(score(Y==i,2)),1,'w','o');hold on   
    text((score(Y==i,1)),(score(Y==i,2)),{i},'color',C(i,:),'fontsize',6,'fontweight','bold');hold on
end

box on
xlabel(['PC 1 (',num2str(e1),'%)'])
ylabel(['PC 2 (',num2str(e2),'%)'])

% xlim([-60 40])
% ylim([-30 30])

xlim([-60 60])
ylim([-20 20])