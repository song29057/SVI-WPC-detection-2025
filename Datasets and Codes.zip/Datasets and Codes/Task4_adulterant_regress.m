clear all;clc

%% load SVI
X = load('D:\Postdoc\Joint papers\Joint_Tang Xuan\Datasets\SVI-adulterants3.csv');
X = X/255;

%% load HSI
% X = load('D:\Postdoc\Joint papers\Joint_Tang Xuan\Datasets\HSI-adulterants3.csv');
% X = X/1982;

%% load Y
Y = 0:0.05:0.5;
Y = repmat(Y,5,1);Y = reshape(Y,55,1);

%% indices
times = 3;  s = 2;  fold = 10;
m = size(Y,1);  index = 1 + rem(0:m-1,times); 
train = find(index~=s);test = find(index==s);
Xtrain = X(train,:);Ytrain = Y(train,:);
Xtest = X(test,:);Ytest = Y(test,:);
indices = 1 + rem(0:size(Xtrain,1)-1,fold);    
% indices = crossvalind('Kfold',ones(size(Xtrain,1),1),fold);      

%% PLSR
% LV = 10;
% cv = plscv(Xtrain,Ytrain,LV,fold,'center',0,2);  %% autoscaling center
% optLV = cv.optLV;
% Ycv = cv.Ypred(:,optLV);
% model = pls(Xtrain,Ytrain,optLV,'center');
% beta = abs(model.regcoef_pretreat');
% [yp,~] = plsval(model,Xtest,Ytest,optLV);
% Yp = yp;

%% K-ELM
C = 1:10;Gamma = 1:10;
for i = 1:size(C,2)
    for j = 1:size(Gamma,2)
        for k = 1:fold
            test_ = (indices == k);  train_ = ~test_;
            xtrain = Xtrain(train_,:);    xtest = Xtrain(test_,:);
            ytrain = Ytrain(train_,:);    ytest = Ytrain(test_,:);
            train_data = [ytrain xtrain];
            test_data = [ytest xtest];
            [yfit, ycv,~] = kelm(train_data,test_data,0,2^C(i),'RBF_kernel',2^Gamma(j));
            Ycv(test_,:) = ycv';
        end
        [rmsecv,r2cv] = regress_results(Ytrain,Ycv);
        R2cv_all(i,j) = r2cv;
        RMSEcv_all(i,j) = rmsecv;
    end
end
[a,b] = find(RMSEcv_all==min(min(RMSEcv_all)));a = a(1);b = b(1);

for k = 1:fold
    test_ = (indices == k);  train_ = ~test_;
    xtrain = Xtrain(train_,:);    xtest = Xtrain(test_,:);
    ytrain = Ytrain(train_,:);    ytest = Ytrain(test_,:);
    train_data = [ytrain xtrain];
    test_data = [ytest xtest];
    [yfit, ycv,~] = kelm(train_data,test_data,0,2^C(a),'RBF_kernel',2^Gamma(b));
    Ycv(test_,:) = ycv';
end
[rmsecv,r2cv] = regress_results(Ytrain,Ycv);
R2cv_all(i,j) = r2cv;
RMSEcv_all(i,j) = rmsecv;

train_data = [Ytrain Xtrain];test_data = [Ytest Xtest];
[~,yp,OutputWeight] = kelm(train_data,test_data,0,2^C(a),'RBF_kernel',2^Gamma(b));
Yp = yp';

%% accuracy
[RMSEcv,MAEcv,R2cv] = regress_results1(Ytrain,Ycv);
[RMSEp,MAEp,R2p] = regress_results1(Ytest,Yp);
Results = [RMSEcv,MAEcv,R2cv;RMSEp,MAEp,R2p];
Results = roundn(Results,-4)

%% Plot
c1 = [0.0000  0.4470  0.7410];  %% blue
c2 = [0.8500  0.3250  0.0980];  %% red
c3 = [0.9290  0.6940  0.1250];  %% yellow
c4 = [0.4940  0.1840  0.5560];  %% purple
c5 = [0.4660  0.6740  0.1880];  %% green
c6 = [0.3010  0.7450  0.9330];  %% blue
c7 = [0.6350  0.0780  0.1840];  %% red

mi = min([Y;Yp]);mi = roundn(mi,-2);
ma = max([Y;Yp]);ma = roundn(ma,-2);
int = (ma - mi)/20;
x0 = mi - int;x1 = ma + int;
y0 = mi - int;y1 = ma + int;

figure
h4 = plot(0:0.05:1,0:0.05:1,'color',[0.8 0.8 0.8]);hold on
% h2 = scatter(Ytrain,Ycv,30,'o','MarkerEdgeColor',c1,'MarkerFaceColor',[1 1 1]);hold on;
h1 = scatter(Ytest,Yp,20,'+','MarkerEdgeColor',c2,'MarkerFaceColor',[1 1 1]);hold on;

% xlim([x0 x1]);ylim([y0 y1])
xlim([-0.035 0.535]);ylim([-0.035 0.535])
xlabel('True'); 
ylabel('Predicted'); 
box on
yticks(0:0.1:0.5)
xticks(0:0.1:0.5)
